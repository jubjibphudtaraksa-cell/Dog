# FIATX2 HUB Bot

Discord bot + small API server (Express), TypeScript, standalone project (no monorepo dependency needed).

## Setup

1. Install dependencies:
   ```
   npm install
   ```
2. Copy `.env.example` to `.env` and fill in real values:
   ```
   PORT=3000
   DISCORD_BOT_TOKEN=your_token_here
   ```
3. Build:
   ```
   npm run build
   ```
4. Start:
   ```
   npm start
   ```

For local development with auto-restart on file changes:
```
npm run dev
```

## Deploying (e.g. Railway / Render / Fly.io)

1. Push this folder to a GitHub repo (make sure `.env` is NOT committed — it's already in `.gitignore`).
2. Create a new project on the host, connect the repo.
3. Set environment variables in the host's dashboard: `PORT` (most hosts set this automatically), `DISCORD_BOT_TOKEN`, `NODE_ENV=production`.
4. Set the build command to `npm run build` and start command to `npm start`.

## Notes on this version

- Removed the `@workspace/api-zod` import in `src/routes/health.ts` (that package lived in a monorepo that wasn't provided) and replaced it with an inline `zod` schema — same behavior, no external workspace dependency.
- Everything else is unchanged from what you provided.
