import { Router, type IRouter } from "express";
import { z } from "zod";

// Inline replacement for the missing "@workspace/api-zod" monorepo package.
const HealthCheckResponse = z.object({
  status: z.enum(["ok", "error"]),
});

const router: IRouter = Router();

router.get("/healthz", (_req, res) => {
  const data = HealthCheckResponse.parse({ status: "ok" });
  res.json(data);
});

export default router;
