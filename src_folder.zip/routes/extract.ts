import { Router } from "express";
import { extractUrl } from "../lib/extractor";

const router = Router();

router.post("/extract", async (req, res) => {
  const { url } = req.body as { url?: string };
  if (!url || !/^https?:\/\//i.test(url)) {
    res.status(400).json({ success: false, message: "Invalid URL" });
    return;
  }
  const result = await extractUrl(url);
  res.json(result);
});

export default router;
