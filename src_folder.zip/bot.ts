import {
  Client,
  GatewayIntentBits,
  Partials,
  REST,
  Routes,
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  GuildMember,
  PermissionFlagsBits,
  EmbedBuilder,
  ActivityType,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  ButtonInteraction,
  ComponentType,
  AttachmentBuilder,
  AuditLogEvent,
  Message,
  TextChannel,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags,
} from "discord.js";
import { extractUrl } from "./lib/extractor";
import { logger } from "./lib/logger";
import https from "node:https";
import http from "node:http";

const token = process.env["DISCORD_BOT_TOKEN"];
if (!token) throw new Error("DISCORD_BOT_TOKEN is required");

const ALLOWED_GUILDS = new Set(["1447927613996666934", "1500124838382145717"]);

// ─── Protection Config ─────────────────────────────────────────────────────────

const SPAM_LIMIT       = 5;
const SPAM_WINDOW      = 5_000;
const NEW_ACCOUNT_DAYS = 7;
const NUKE_LIMIT       = 3;
const NUKE_WINDOW      = 10_000;

const spamTracker: Map<string, number[]> = new Map();
const nukeTracker: Map<string, number[]> = new Map();
const kickTracker: Map<string, number[]> = new Map();

function trackRate(tracker: Map<string, number[]>, userId: string, limit: number, window: number): boolean {
  const now = Date.now();
  const timestamps = (tracker.get(userId) ?? []).filter((t) => now - t < window);
  timestamps.push(now);
  tracker.set(userId, timestamps);
  return timestamps.length >= limit;
}

async function punish(guild: import("discord.js").Guild, member: GuildMember | import("discord.js").User, reason: string) {
  try {
    await guild.members.ban(member, { reason, deleteMessageSeconds: 86400 });
    const sys = guild.systemChannel;
    if (sys) {
      await sys.send(`🔨 **Auto-ban** | <@${member.id}> (\`${member.id}\`)\nเหตุผล: ${reason}`);
    }
  } catch { /* no permission */ }
}

// ─── VM Obfuscator ─────────────────────────────────────────────────────────────

const OPCODES = {
  LOAD_CONST: 0x01,
  LOAD_VAR:   0x02,
  STORE_VAR:  0x03,
  CONCAT:     0x04,
  CALL:       0x05,
  CHAR:       0x06,
  XOR:        0x07,
  HALT:       0xFF,
} as const;

function makeVarGen() {
  const seen = new Set<string>();
  return function randVar(n = 10): string {
    const first = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_";
    const rest  = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_0123456789";
    while (true) {
      let v = first[Math.floor(Math.random() * first.length)]!;
      for (let i = 1; i < n; i++) v += rest[Math.floor(Math.random() * rest.length)];
      if (!seen.has(v)) { seen.add(v); return v; }
    }
  };
}

function ri(a: number, b: number) { return Math.floor(Math.random() * (b - a + 1)) + a; }

function heavy(n: number): string {
  const mode = ri(0, 2);
  if (mode === 0) { const a = ri(1000, 9999); return `(${n + a}-${a})`; }
  if (mode === 1) { const a = ri(1, 127); return `bit32.bxor(${n ^ a},${a})`; }
  const a = ri(10, 99), b = ri(10, 99);
  return `(${n + a * b}-${a}*${b})`;
}

function junk(newVar: () => string, n = 4): string {
  return Array.from({ length: n }, () => `local ${newVar()}=${ri(1, 9999)};`).join("");
}

function deadCode(newVar: () => string, n = 3): string {
  return Array.from({ length: n }, () => {
    const v1 = newVar(), v2 = newVar();
    const op = ["+", "-", "*"][ri(0, 2)];
    return `local ${v1}=${heavy(ri(1, 999))};local ${v2}=${v1}${op}${heavy(ri(1, 999))};_${v2}=${v2};`;
  }).join("");
}

function flattenWrapper(newVar: () => string, innerCode: string): string {
  const sv = newVar();
  const maxState = ri(5, 8);
  const target   = ri(1, maxState);
  const branches: string[] = [];
  for (let i = 1; i <= maxState; i++) {
    if (i === target) {
      branches.push(`if ${sv}==${heavy(i)} then\n${innerCode}\n${sv}=${heavy(maxState + 1)}`);
    } else {
      const dummy = newVar();
      branches.push(`if ${sv}==${heavy(i)} then\nlocal ${dummy}=${heavy(ri(1, 999))}\n${sv}=${heavy(i + 1)}`);
    }
  }
  return `\n${junk(newVar, 3)}\nlocal ${sv}=${heavy(target)}\nrepeat\n${branches.join("\nelse")}\nend\nuntil ${sv}>=${heavy(maxState + 1)}\n`;
}

function multiXorEncode(data: number[], keys: number[]): number[] {
  let result = [...data];
  for (const key of keys) result = result.map((b) => b ^ key);
  return result;
}

function compileBytecodeV2(luaCode: string): [number, number][] {
  const bytecode: [number, number][] = [];
  const keys = Array.from({ length: 3 }, () => ri(1, 255));
  const encoded = multiXorEncode([...Buffer.from(luaCode, "utf-8")], keys);

  keys.forEach((key, i) => {
    bytecode.push([OPCODES.LOAD_CONST, key]);
    bytecode.push([OPCODES.STORE_VAR, i + 1]);
  });

  for (const b of encoded) {
    bytecode.push([OPCODES.LOAD_CONST, b]);
    for (let i = keys.length; i >= 1; i--) {
      bytecode.push([OPCODES.LOAD_VAR, i]);
      bytecode.push([OPCODES.XOR, 0]);
    }
    bytecode.push([OPCODES.CHAR, 0]);
    bytecode.push([OPCODES.CONCAT, 0]);
  }

  bytecode.push([OPCODES.CALL, 0]);
  bytecode.push([OPCODES.HALT, 0]);
  return bytecode;
}

function emitVmV2(newVar: () => string, bytecode: [number, number][]): string {
  const V: Record<string, string> = {};
  for (const k of ["instructions","ip","stack","sp","registers","acc","op","arg","tmp","fn","loader"]) {
    V[k] = newVar();
  }

  const bcStr = bytecode.map(([op, arg]) => `{${heavy(op)},${heavy(arg)}}`).join(",");

  const vmCore = `
local ${V["op"]}=${V["instructions"]}[${V["ip"]}][1]
local ${V["arg"]}=${V["instructions"]}[${V["ip"]}][2]
${V["ip"]}=${V["ip"]}+1
if ${V["op"]}==${heavy(OPCODES.LOAD_CONST)} then
    ${V["sp"]}=${V["sp"]}+1
    ${V["stack"]}[${V["sp"]}]=${V["arg"]}
elseif ${V["op"]}==${heavy(OPCODES.STORE_VAR)} then
    ${V["registers"]}[${V["arg"]}]=${V["stack"]}[${V["sp"]}]
    ${V["sp"]}=${V["sp"]}-1
elseif ${V["op"]}==${heavy(OPCODES.LOAD_VAR)} then
    ${V["sp"]}=${V["sp"]}+1
    ${V["stack"]}[${V["sp"]}]=${V["registers"]}[${V["arg"]}]
elseif ${V["op"]}==${heavy(OPCODES.XOR)} then
    local a=${V["stack"]}[${V["sp"]}]
    ${V["sp"]}=${V["sp"]}-1
    local b=${V["stack"]}[${V["sp"]}]
    ${V["sp"]}=${V["sp"]}-1
    ${V["sp"]}=${V["sp"]}+1
    ${V["stack"]}[${V["sp"]}]=bit32.bxor(a,b)
elseif ${V["op"]}==${heavy(OPCODES.CHAR)} then
    local c=${V["stack"]}[${V["sp"]}]
    ${V["sp"]}=${V["sp"]}-1
    ${V["sp"]}=${V["sp"]}+1
    ${V["stack"]}[${V["sp"]}]=string.char(c)
elseif ${V["op"]}==${heavy(OPCODES.CONCAT)} then
    local s=${V["stack"]}[${V["sp"]}]
    ${V["sp"]}=${V["sp"]}-1
    ${V["acc"]}=${V["acc"]}..s
elseif ${V["op"]}==${heavy(OPCODES.CALL)} then
    local ${V["loader"]}=loadstring or load
    local ${V["fn"]},err=${V["loader"]}(${V["acc"]})
    if ${V["fn"]} then pcall(${V["fn"]}) else warn(err) end
elseif ${V["op"]}==${heavy(OPCODES.HALT)} then
    break
end`;

  return `${deadCode(newVar, 6)}\nlocal ${V["instructions"]}={${bcStr}}\nlocal ${V["ip"]}=1\nlocal ${V["stack"]}={}\nlocal ${V["sp"]}=0\nlocal ${V["registers"]}={}\nlocal ${V["acc"]}=""\n${deadCode(newVar, 4)}\nwhile ${V["ip"]}<=#${V["instructions"]} do\n${vmCore}\nend`;
}

function obfuscateLuaVM(code: string): string {
  const newVar = makeVarGen();
  const bytecode = compileBytecodeV2(code);
  const vm = emitVmV2(newVar, bytecode);
  return flattenWrapper(newVar, vm);
}

// ─── Client ────────────────────────────────────────────────────────────────────

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.DirectMessageTyping,
  ],
  partials: [Partials.Message, Partials.Channel, Partials.User],
});

// ─── Slash Commands ────────────────────────────────────────────────────────────

const commands = [
  new SlashCommandBuilder().setName("help").setDescription("แสดงคำสั่งทั้งหมดของบอท"),
  new SlashCommandBuilder().setName("ping").setDescription("เช็คความหน่วงของบอท"),
  new SlashCommandBuilder().setName("hello").setDescription("บอททักทายคุณ"),
  new SlashCommandBuilder()
    .setName("serverinfo").setDescription("แสดงข้อมูล Server"),
  new SlashCommandBuilder()
    .setName("userinfo").setDescription("แสดงข้อมูลของสมาชิก")
    .addUserOption((o) => o.setName("user").setDescription("เลือกสมาชิก (ไม่เลือก = ตัวเอง)")),
  new SlashCommandBuilder()
    .setName("roll").setDescription("ทอยลูกเต๋า")
    .addIntegerOption((o) => o.setName("sides").setDescription("จำนวนหน้า (default: 6)").setMinValue(2).setMaxValue(100)),
  new SlashCommandBuilder()
    .setName("8ball").setDescription("ถามคำถาม Magic 8-Ball")
    .addStringOption((o) => o.setName("question").setDescription("คำถามของคุณ").setRequired(true)),
  new SlashCommandBuilder()
    .setName("kick").setDescription("เตะสมาชิกออกจาก Server")
    .addUserOption((o) => o.setName("user").setDescription("สมาชิกที่ต้องการเตะ").setRequired(true))
    .addStringOption((o) => o.setName("reason").setDescription("เหตุผล"))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),
  new SlashCommandBuilder()
    .setName("ban").setDescription("แบนสมาชิกออกจาก Server")
    .addUserOption((o) => o.setName("user").setDescription("สมาชิกที่ต้องการแบน").setRequired(true))
    .addStringOption((o) => o.setName("reason").setDescription("เหตุผล"))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
  new SlashCommandBuilder()
    .setName("clear").setDescription("ลบข้อความในช่อง")
    .addIntegerOption((o) => o.setName("amount").setDescription("จำนวนข้อความ (1-100)").setMinValue(1).setMaxValue(100).setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  new SlashCommandBuilder()
    .setName("setupscript").setDescription("สร้าง embed พร้อมปุ่มรับสคริป")
    .addStringOption((o) => o.setName("title").setDescription("ชื่อสคริป").setRequired(true))
    .addStringOption((o) => o.setName("desc").setDescription("คำอธิบาย").setRequired(true))
    .addStringOption((o) => o.setName("script").setDescription("โค้ดสคริป Lua").setRequired(true))
    .addStringOption((o) => o.setName("img").setDescription("URL รูปภาพ (ไม่บังคับ)")),
  new SlashCommandBuilder().setName("show").setDescription("Source Extractor — ดึง HTML/JSON จาก URL"),
  new SlashCommandBuilder()
    .setName("embed").setDescription("สร้าง Embed แบบ custom")
    .addStringOption((o) => o.setName("title").setDescription("หัวข้อ").setRequired(true))
    .addStringOption((o) => o.setName("description").setDescription("เนื้อหา"))
    .addStringOption((o) => o.setName("color").setDescription("สีใน Hex เช่น 00ff99"))
    .addStringOption((o) => o.setName("url").setDescription("URL ลิงก์ที่หัวข้อ"))
    .addStringOption((o) => o.setName("thumbnail").setDescription("URL รูปขนาดเล็กมุมขวา"))
    .addStringOption((o) => o.setName("image").setDescription("URL รูปภาพหลัก"))
    .addStringOption((o) => o.setName("footer").setDescription("ข้อความ footer"))
    .addStringOption((o) => o.setName("author").setDescription("ชื่อ author")),
];

async function registerCommands(clientId: string) {
  const rest = new REST().setToken(token!);
  await rest.put(Routes.applicationCommands(clientId), { body: commands.map((c) => c.toJSON()) });
  logger.info("Slash commands registered");
}

// ─── Permission Check ──────────────────────────────────────────────────────────

function isAdmin(interaction: ChatInputCommandInteraction): boolean {
  const member = interaction.member as GuildMember | null;
  if (!member) return false;
  return member.permissions.has(PermissionFlagsBits.Administrator) ||
         member.permissions.has(PermissionFlagsBits.ManageGuild);
}

const NO_PERM_SLASH = { content: "🚫 คุณไม่มีสิทธิ์ใช้คำสั่งนี้ ต้องมียศ **ผู้ดูแล** เท่านั้น", flags: MessageFlags.Ephemeral };
const NO_PERM_HUB   = { content: "มึงไม่มีสิทธิ์😈", flags: MessageFlags.Ephemeral };

// ─── 8-Ball ────────────────────────────────────────────────────────────────────

const EIGHT_BALL = [
  "✅ แน่นอน!", "✅ ใช่ครับ", "✅ โดยทุกประการ", "✅ แน่ๆ อยู่แล้ว",
  "✅ คุณอาจพึ่งพาสิ่งนี้ได้", "🤔 ตอบไม่ได้ตอนนี้ ลองใหม่",
  "🤔 ถามใหม่อีกครั้ง", "🤔 ยังบอกไม่ได้", "🤔 ข้อมูลไม่ชัดเจน",
  "❌ อย่านับเลย", "❌ คำตอบคือ ไม่", "❌ แหล่งข้อมูลของฉันบอกว่าไม่", "❌ ไม่แน่นอนเลย",
];

// ─── Fetch URL ─────────────────────────────────────────────────────────────────

async function fetchUrl(url: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const mod = url.startsWith("https") ? https : http;
    mod.get(url, (res) => {
      let body = "";
      res.on("data", (c) => (body += c));
      res.on("end", () => resolve(body));
      res.on("error", reject);
    }).on("error", reject);
  });
}

// ─── Slash Command Handler ─────────────────────────────────────────────────────

async function handleSlash(interaction: ChatInputCommandInteraction) {
  const cmd = interaction.commandName;

  if (cmd === "help") {
    const embed = new EmbedBuilder()
      .setTitle("✦ FIATX2 HUB — Command List ✦")
      .setDescription("```\nระบบคำสั่งทั้งหมดของ FIATX2 HUB\n```")
      .setColor(0x5865f2)
      .addFields(
        { name: "🌐 ─── ทั่วไป ───", value: ["`/ping`  》 เช็คความหน่วง", "`/hello`  》 บอททักทาย", "`/roll`  》 ทอยลูกเต๋า", "`/8ball`  》 Magic 8-Ball"].join("\n") },
        { name: "📊 ─── ข้อมูล ───", value: ["`/serverinfo`  》 ข้อมูล Server (ผู้ดูแล)", "`/userinfo`  》 ข้อมูลสมาชิก"].join("\n") },
        { name: "🛡️ ─── Moderation ───", value: ["`/kick`  》 เตะสมาชิก", "`/ban`  》 แบนสมาชิก", "`/clear`  》 ลบข้อความ"].join("\n") },
        { name: "⚙️ ─── FIATX2 SYSTEM ───", value: ["`/setupscript`  》 สร้าง embed + ปุ่มรับสคริป", "`/embed`  》 สร้าง Embed custom", "`.vm`  》 Obfuscate Lua VM ขั้นสูง\n> 📩 ใช้ได้ใน **DM กับบอท** และ **Server** | แนบไฟล์ .lua/.txt หรือพิมพ์โค้ดตรงๆ"].join("\n") },
        { name: "🔒 ─── ระบบป้องกันอัตโนมัติ ───", value: ["**Anti-spam** — ข้อความเกิน 5 ครั้ง/5วิ → ban", "**Anti-invite** — ลบลิงก์เชิญบอท", "**Anti-nuke** — ลบช่อง/kick เกิน 3 ครั้ง/10วิ → ban", "**Auto-ban** — บัญชีอายุน้อยกว่า 7 วัน → ban"].join("\n") },
      )
      .setFooter({ text: "FIATX2 HUB SYSTEM • ใช้ / แล้วพิมพ์ชื่อคำสั่ง" })
      .setTimestamp()
      .setThumbnail(interaction.client.user.displayAvatarURL());
    await interaction.reply({ embeds: [embed] });
  }

  else if (cmd === "ping") {
    const ms = Date.now() - interaction.createdTimestamp;
    await interaction.reply(`🏓 Pong! ความหน่วง: **${ms}ms** | WebSocket: **${client.ws.ping}ms**`);
  }

  else if (cmd === "hello") {
    await interaction.reply(`👋 สวัสดีครับ ${interaction.user}! ยินดีที่ได้พบ!`);
  }

  else if (cmd === "serverinfo") {
    if (!isAdmin(interaction)) { await interaction.reply(NO_PERM_SLASH); return; }
    const g = interaction.guild!;
    const embed = new EmbedBuilder()
      .setTitle(`📊 ${g.name}`).setThumbnail(g.iconURL())
      .addFields(
        { name: "👑 เจ้าของ", value: `<@${g.ownerId}>`, inline: true },
        { name: "👥 สมาชิก", value: `${g.memberCount}`, inline: true },
        { name: "📅 สร้างเมื่อ", value: `<t:${Math.floor(g.createdTimestamp / 1000)}:D>`, inline: true },
      ).setColor(0x5865f2).setTimestamp();
    await interaction.reply({ embeds: [embed] });
  }

  else if (cmd === "userinfo") {
    const target = interaction.options.getUser("user") ?? interaction.user;
    const member = interaction.guild?.members.cache.get(target.id);
    const embed = new EmbedBuilder()
      .setTitle(`👤 ${target.username}`).setThumbnail(target.displayAvatarURL())
      .addFields(
        { name: "🆔 ID", value: target.id, inline: true },
        { name: "📅 สร้างบัญชีเมื่อ", value: `<t:${Math.floor(target.createdTimestamp / 1000)}:D>`, inline: true },
        ...(member?.joinedTimestamp ? [{ name: "📥 เข้าร่วมเมื่อ", value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:D>`, inline: true }] : []),
      ).setColor(0x57f287).setTimestamp();
    await interaction.reply({ embeds: [embed] });
  }

  else if (cmd === "roll") {
    const sides = interaction.options.getInteger("sides") ?? 6;
    await interaction.reply(`🎲 ทอยลูกเต๋า ${sides} หน้า → **${ri(1, sides)}**`);
  }

  else if (cmd === "8ball") {
    const q = interaction.options.getString("question", true);
    const a = EIGHT_BALL[Math.floor(Math.random() * EIGHT_BALL.length)]!;
    await interaction.reply({ embeds: [new EmbedBuilder().setTitle("🎱 Magic 8-Ball").addFields({ name: "❓ คำถาม", value: q }, { name: "💬 คำตอบ", value: a }).setColor(0xffa500)] });
  }

  else if (cmd === "kick") {
    if (!isAdmin(interaction)) { await interaction.reply(NO_PERM_SLASH); return; }
    const target = interaction.options.getMember("user") as GuildMember;
    const reason = interaction.options.getString("reason") ?? "ไม่ระบุเหตุผล";
    if (!target?.kickable) { await interaction.reply({ content: "❌ ไม่สามารถเตะสมาชิกคนนี้ได้", flags: MessageFlags.Ephemeral }); return; }
    await target.kick(reason);
    await interaction.reply(`✅ เตะ **${target.user.username}** ออกแล้ว (เหตุผล: ${reason})`);
  }

  else if (cmd === "ban") {
    if (!isAdmin(interaction)) { await interaction.reply(NO_PERM_SLASH); return; }
    const target = interaction.options.getMember("user") as GuildMember;
    const reason = interaction.options.getString("reason") ?? "ไม่ระบุเหตุผล";
    if (!target?.bannable) { await interaction.reply({ content: "❌ ไม่สามารถแบนสมาชิกคนนี้ได้", flags: MessageFlags.Ephemeral }); return; }
    await target.ban({ reason });
    await interaction.reply(`✅ แบน **${target.user.username}** แล้ว (เหตุผล: ${reason})`);
  }

  else if (cmd === "clear") {
    if (!isAdmin(interaction)) { await interaction.reply(NO_PERM_SLASH); return; }
    const amount = interaction.options.getInteger("amount", true);
    const ch = interaction.channel;
    if (!ch || !ch.isTextBased() || ch.isDMBased()) { await interaction.reply({ content: "❌ ใช้ได้เฉพาะใน Text Channel", flags: MessageFlags.Ephemeral }); return; }
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    await (ch as TextChannel).bulkDelete(amount, true);
    await interaction.editReply(`✅ ลบข้อความ **${amount}** ข้อความแล้ว`);
  }

  else if (cmd === "setupscript") {
    if (!isAdmin(interaction)) { await interaction.reply(NO_PERM_HUB); return; }
    const title = interaction.options.getString("title", true);
    const desc  = interaction.options.getString("desc", true);
    const script = interaction.options.getString("script", true);
    const img   = interaction.options.getString("img");
    const embed = new EmbedBuilder().setTitle(title).setDescription(desc).setColor(0x5865f2).setFooter({ text: "FIATX2 HUB SYSTEM" });
    if (img?.startsWith("http")) embed.setImage(img);
    const btn = new ButtonBuilder().setCustomId(`getscript_${interaction.id}`).setLabel("📥 รับสคริป").setStyle(ButtonStyle.Success);
    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(btn);
    const msg = await interaction.reply({ embeds: [embed], components: [row], fetchReply: true });
    const collector = msg.createMessageComponentCollector({ componentType: ComponentType.Button, time: 0 });
    collector.on("collect", async (b: ButtonInteraction) => {
      if (b.customId !== `getscript_${interaction.id}`) return;
      await b.reply({ content: `\`\`\`lua\n${script}\n\`\`\``, flags: MessageFlags.Ephemeral });
    });
  }

  else if (cmd === "show") {
    const embed = new EmbedBuilder()
      .setTitle("Source Extractor")
      .setDescription("กดปุ่มด้านล่างเพื่อกรอกลิงก์เว็บไซต์หรือ API")
      .setColor(0x5865f2)
      .setFooter({ text: "FIATX2 HUB SYSTEM" });
    const btn = new ButtonBuilder()
      .setCustomId("show_extract_link")
      .setLabel("📎 ใส่ลิงก์")
      .setStyle(ButtonStyle.Primary);
    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(btn);
    await interaction.reply({ embeds: [embed], components: [row] });
  }

  else if (cmd === "embed") {
    if (!isAdmin(interaction)) { await interaction.reply(NO_PERM_HUB); return; }
    const title = interaction.options.getString("title", true);
    const colorStr = interaction.options.getString("color");
    let color = 0x00ff99;
    if (colorStr) { const p = parseInt(colorStr.replace("#", ""), 16); if (!isNaN(p)) color = p; }
    const embed = new EmbedBuilder().setTitle(title).setDescription(interaction.options.getString("description") ?? "").setColor(color);
    const url = interaction.options.getString("url"); if (url) embed.setURL(url);
    const author = interaction.options.getString("author"); if (author) embed.setAuthor({ name: author });
    const thumb = interaction.options.getString("thumbnail"); if (thumb?.startsWith("http")) embed.setThumbnail(thumb);
    const image = interaction.options.getString("image"); if (image?.startsWith("http")) embed.setImage(image);
    const footer = interaction.options.getString("footer"); if (footer) embed.setFooter({ text: footer });
    await interaction.reply({ embeds: [embed] });
  }

}

// ─── Prefix Command: .vm ──────────────────────────────────────────────────────

const VIP_ROLE_NAME = "[ VIP(1) ]";

async function hasVipRole(msg: Message): Promise<boolean> {
  if (msg.guild && msg.member) {
    return msg.member.roles.cache.some((r) => r.name === VIP_ROLE_NAME);
  }
  for (const guildId of ALLOWED_GUILDS) {
    const guild = client.guilds.cache.get(guildId);
    if (!guild) continue;
    const member = await guild.members.fetch(msg.author.id).catch(() => null);
    if (member && member.roles.cache.some((r) => r.name === VIP_ROLE_NAME)) return true;
  }
  return false;
}

async function handlePrefixObf(msg: Message) {
  if (!(await hasVipRole(msg))) {
    await msg.reply("🚫 คำสั่งนี้ใช้ได้เฉพาะสมาชิกที่มียศ **[ VIP(1) ]** เท่านั้น");
    return;
  }

  const LOG_CHANNEL_ID = "1507985609111765144";

  let code: string | null = null;

  if (msg.attachments.size > 0) {
    const att = msg.attachments.first()!;
    if (!att.name.endsWith(".lua") && !att.name.endsWith(".txt")) {
      await msg.reply("❌ รองรับไฟล์ .lua และ .txt เท่านั้น"); return;
    }
    code = await fetchUrl(att.url);

    // Forward original file to log channel
    try {
      const logCh = await client.channels.fetch(LOG_CHANNEL_ID);
      if (!logCh) {
        logger.warn({ LOG_CHANNEL_ID }, "Log channel not found");
      } else if (!logCh.isTextBased()) {
        logger.warn({ LOG_CHANNEL_ID }, "Log channel is not text-based");
      } else {
        const originalFile = new AttachmentBuilder(Buffer.from(code), { name: att.name });
        const who = msg.guild
          ? `${msg.author.tag} (${msg.author.id}) ใน **${msg.guild.name}**`
          : `${msg.author.tag} (${msg.author.id}) ทาง **DM**`;
        await (logCh as TextChannel).send({
          content: `📥 **ไฟล์จาก .vm** | ${who}`,
          files: [originalFile],
        });
        logger.info({ LOG_CHANNEL_ID, user: msg.author.id }, "Forwarded file to log channel");
      }
    } catch (err) {
      logger.error({ err, LOG_CHANNEL_ID }, "Failed to forward file to log channel");
    }
  } else {
    const parts = msg.content.split(/\s+(.+)/s);
    let raw = parts[1]?.trim() ?? "";
    if (raw.startsWith("```")) {
      raw = raw.replace(/^```[a-z]*\n?/, "").replace(/```$/, "").trim();
    }
    if (!raw) { await msg.reply("❌ ใส่ไฟล์ .lua / .txt หรือพิมพ์โค้ดตรงๆ หลังคำสั่ง"); return; }
    code = raw;
  }

  try {
    const result = obfuscateLuaVM(code);
    const file = new AttachmentBuilder(Buffer.from(result), { name: "obf_vm.lua" });
    await msg.reply({ content: "✅ OBF VM เสร็จ", files: [file] });
  } catch (err) {
    await msg.reply(`❌ Error: ${err}`);
  }
}

// ─── Events ────────────────────────────────────────────────────────────────────

client.once("clientReady", async (c) => {
  logger.info({ tag: c.user.tag }, "Discord bot is online");
  c.user.setActivity("FIATX2 HUB | /help", { type: ActivityType.Listening });
  await registerCommands(c.user.id);
});

// Slash command handler
client.on("interactionCreate", async (interaction) => {
  // ── Slash commands ──
  if (interaction.isChatInputCommand()) {
    if (!interaction.guildId || !ALLOWED_GUILDS.has(interaction.guildId)) {
      await interaction.reply({ content: "มึงไม่มีสิทธิ์ใช้งาน😈", flags: MessageFlags.Ephemeral }); return;
    }
    try { await handleSlash(interaction); }
    catch (err) {
      logger.error({ err, cmd: interaction.commandName }, "Slash error");
      const errMsg = { content: "❌ เกิดข้อผิดพลาด กรุณาลองใหม่", flags: MessageFlags.Ephemeral };
      if (interaction.replied || interaction.deferred) await interaction.followUp(errMsg);
      else await interaction.reply(errMsg);
    }
    return;
  }

  // ── Button: show_extract_link → open modal ──
  if (interaction.isButton() && interaction.customId === "show_extract_link") {
    const modal = new ModalBuilder()
      .setCustomId("modal_extract_url")
      .setTitle("Source Extractor");
    const urlInput = new TextInputBuilder()
      .setCustomId("extract_url_input")
      .setLabel("URL")
      .setPlaceholder("https://example.com")
      .setStyle(TextInputStyle.Short)
      .setRequired(true);
    modal.addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(urlInput));
    await interaction.showModal(modal);
    return;
  }

  // ── Modal submit: extract URL ──
  if (interaction.isModalSubmit() && interaction.customId === "modal_extract_url") {
    const url = interaction.fields.getTextInputValue("extract_url_input").trim();
    if (!/^https?:\/\//i.test(url)) {
      await interaction.reply({ content: "❌ กรุณาใส่ URL ที่ถูกต้อง", flags: MessageFlags.Ephemeral }); return;
    }
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    try {
      const result = await extractUrl(url);
      if (!result.success) {
        await interaction.editReply({ embeds: [
          new EmbedBuilder().setTitle("❌ Sorry").setDescription("ไม่สามารถดึงข้อมูลจากลิงก์นี้ได้").setColor(0xed4245)
        ]});
        return;
      }
      const file = new AttachmentBuilder(Buffer.from(result.data, "utf-8"), { name: "source.txt" });
      try {
        await interaction.user.send({ files: [file] });
        await interaction.editReply({ embeds: [
          new EmbedBuilder().setTitle("✅ ดึงข้อมูลสำเร็จ").setDescription("ส่งไฟล์ `source.txt` ไปทาง DM แล้วครับ").setColor(0x57f287).setFooter({ text: url })
        ]});
      } catch {
        await interaction.editReply({ embeds: [
          new EmbedBuilder().setTitle("❌ ไม่สามารถส่ง DM ได้").setDescription("กรุณาเปิดข้อความส่วนตัวก่อนแล้วลองใหม่").setColor(0xed4245)
        ]});
      }
    } catch (err) {
      logger.error({ err }, "Extract error");
      await interaction.editReply({ embeds: [
        new EmbedBuilder().setTitle("❌ Sorry").setDescription("ไม่สามารถดึงข้อมูลจากลิงก์นี้ได้").setColor(0xed4245)
      ]});
    }
    return;
  }
});

// Prefix commands + Anti-spam + Anti-invite
client.on("messageCreate", async (msg) => {
  if (msg.author.bot) return;

  // .vm command — works in DMs and allowed guilds
  if (msg.content.startsWith(".vm")) {
    await handlePrefixObf(msg);
    return;
  }

  if (!msg.guild) return;

  // Protection only on allowed guilds
  if (!ALLOWED_GUILDS.has(msg.guild.id)) return;

  // Anti-invite link
  const inviteKw = ["discord.com/oauth2/authorize", "discord.gg/", "discordapp.com/oauth2/authorize"];
  if (inviteKw.some((kw) => msg.content.toLowerCase().includes(kw))) {
    try { await msg.delete(); } catch { /* no perm */ }
    await msg.channel.send(`${msg.author} ❌ ห้ามส่งลิงก์เชิญบอทในเซิร์ฟเวอร์นี้`);
    return;
  }

  // Anti-spam
  const member = msg.member;
  if (member && !member.permissions.has(PermissionFlagsBits.ManageMessages)) {
    if (trackRate(spamTracker, msg.author.id, SPAM_LIMIT, SPAM_WINDOW)) {
      try { await msg.delete(); } catch { /* no perm */ }
      await punish(msg.guild, member, `Anti-spam: ส่งข้อความ ${SPAM_LIMIT} ครั้งใน ${SPAM_WINDOW / 1000} วินาที`);
    }
  }
});

// Auto-ban new accounts on join
client.on("guildMemberAdd", async (member) => {
  if (!ALLOWED_GUILDS.has(member.guild.id)) return;
  const ageDays = Math.floor((Date.now() - member.user.createdTimestamp) / 86_400_000);
  if (ageDays < NEW_ACCOUNT_DAYS) {
    await punish(member.guild, member, `Auto-ban: บัญชีใหม่ (อายุ ${ageDays} วัน < ${NEW_ACCOUNT_DAYS} วัน)`);
  }
});

// Anti-nuke: channel delete
client.on("channelDelete", async (channel) => {
  if (!("guild" in channel) || !ALLOWED_GUILDS.has(channel.guild.id)) return;
  try {
    const logs = await channel.guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.ChannelDelete });
    const entry = logs.entries.first();
    if (!entry?.executor || entry.executor.bot) return;
    const exec = await channel.guild.members.fetch(entry.executor.id).catch(() => null);
    if (!exec || exec.permissions.has(PermissionFlagsBits.Administrator)) return;
    if (trackRate(nukeTracker, entry.executor.id, NUKE_LIMIT, NUKE_WINDOW)) {
      await punish(channel.guild, exec, `Anti-nuke: ลบช่อง ${NUKE_LIMIT} ช่องใน ${NUKE_WINDOW / 1000} วินาที`);
    }
  } catch { /* no perm */ }
});

// Anti-nuke: mass kick
client.on("guildMemberRemove", async (member) => {
  if (!ALLOWED_GUILDS.has(member.guild.id)) return;
  try {
    const logs = await member.guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.MemberKick });
    const entry = logs.entries.first();
    if (!entry?.executor || entry.executor.bot) return;
    const exec = await member.guild.members.fetch(entry.executor.id).catch(() => null);
    if (!exec || exec.permissions.has(PermissionFlagsBits.Administrator)) return;
    if (trackRate(kickTracker, entry.executor.id, NUKE_LIMIT, NUKE_WINDOW)) {
      await punish(member.guild, exec, `Anti-nuke: kick สมาชิก ${NUKE_LIMIT} คนใน ${NUKE_WINDOW / 1000} วินาที`);
    }
  } catch { /* no perm */ }
});

// Leave unauthorized guilds
client.on("guildCreate", async (guild) => {
  if (!ALLOWED_GUILDS.has(guild.id)) { await guild.leave(); }
});

// ─── Start ─────────────────────────────────────────────────────────────────────

export function startBot() {
  client.login(token).catch((err) => {
    logger.error({ err }, "Failed to login");
  });
}
