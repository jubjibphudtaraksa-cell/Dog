import https from "node:https";
import http from "node:http";
import zlib from "node:zlib";
import { URL } from "node:url";

export interface ExtractResult {
  success: true;
  type: "website" | "api";
  filename: string;
  data: string;
}

export interface ExtractError {
  success: false;
  message: string;
}

export type ExtractResponse = ExtractResult | ExtractError;

const HEADERS = {
  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
  "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,application/json,*/*;q=0.8",
  "Accept-Language": "en-US,en;q=0.9",
  "Accept-Encoding": "gzip, deflate, br",
  "Connection": "close",
};

function decompress(res: http.IncomingMessage, chunks: Buffer[]): Promise<string> {
  const raw = Buffer.concat(chunks);
  const enc = (res.headers["content-encoding"] ?? "").toLowerCase();
  return new Promise((resolve, reject) => {
    if (enc === "gzip") {
      zlib.gunzip(raw, (err, buf) => err ? reject(err) : resolve(buf.toString("utf-8")));
    } else if (enc === "deflate") {
      zlib.inflate(raw, (err, buf) => err ? reject(err) : resolve(buf.toString("utf-8")));
    } else if (enc === "br") {
      zlib.brotliDecompress(raw, (err, buf) => err ? reject(err) : resolve(buf.toString("utf-8")));
    } else {
      resolve(raw.toString("utf-8"));
    }
  });
}

function doRequest(url: string, redirects = 0): Promise<ExtractResponse> {
  return new Promise((resolve) => {
    if (redirects > 5) { resolve({ success: false, message: "Sorry" }); return; }

    let parsed: URL;
    try { parsed = new URL(url); } catch { resolve({ success: false, message: "Sorry" }); return; }

    const mod = parsed.protocol === "https:" ? https : http;
    const opts = {
      hostname: parsed.hostname,
      port: parsed.port || (parsed.protocol === "https:" ? 443 : 80),
      path: parsed.pathname + parsed.search,
      method: "GET",
      headers: HEADERS,
      timeout: 15_000,
      rejectUnauthorized: false,
    };

    const req = mod.request(opts, (res) => {
      if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        const next = res.headers.location.startsWith("http")
          ? res.headers.location
          : new URL(res.headers.location, url).toString();
        res.resume();
        resolve(doRequest(next, redirects + 1));
        return;
      }

      const chunks: Buffer[] = [];
      res.on("data", (c: Buffer) => chunks.push(c));
      res.on("end", async () => {
        try {
          const body = await decompress(res, chunks);
          const ct = (res.headers["content-type"] ?? "").toLowerCase();

          if (ct.includes("application/json")) {
            resolve({ success: true, type: "api", filename: "source.txt", data: body });
          } else if (ct.includes("text/html") || ct.includes("text/plain") || ct.includes("text/xml") || ct.includes("application/xml")) {
            resolve({ success: true, type: "website", filename: "source.txt", data: body });
          } else if (body.trimStart().startsWith("{") || body.trimStart().startsWith("[")) {
            resolve({ success: true, type: "api", filename: "source.txt", data: body });
          } else if (body.trimStart().toLowerCase().startsWith("<!doctype") || body.trimStart().startsWith("<html")) {
            resolve({ success: true, type: "website", filename: "source.txt", data: body });
          } else if (body.length > 0) {
            resolve({ success: true, type: "website", filename: "source.txt", data: body });
          } else {
            resolve({ success: false, message: "Sorry" });
          }
        } catch {
          resolve({ success: false, message: "Sorry" });
        }
      });
      res.on("error", () => resolve({ success: false, message: "Sorry" }));
    });

    req.on("error", () => resolve({ success: false, message: "Sorry" }));
    req.on("timeout", () => { req.destroy(); resolve({ success: false, message: "Sorry" }); });
    req.end();
  });
}

export async function extractUrl(url: string): Promise<ExtractResponse> {
  return doRequest(url);
}
