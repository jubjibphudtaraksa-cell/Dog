# FiatX2 Bot

Discord bot.
